Compile with MinGW.
You will also need to install the SDL library (http://www.libsdl.org/).
Zlib is required for zipped rom support.

Please distribute required dlls with the executable.