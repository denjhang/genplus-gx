/**
 * @file	compiler.h
 * @brief	include file for standard system include files,
 *			or project specific include files that are used frequently,
 *			but are changed infrequently
 */

#pragma once

#include <stdio.h>
#include <windows.h>

typedef unsigned char UINT8;
typedef signed int SINT32;
typedef INT_PTR INTPTR;
